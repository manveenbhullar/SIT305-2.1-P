package com.example.task21;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageButton imgBtn1, imgBtn2, imgBtn3;
    TextView text1, text2, text3;
    EditText editText;
    float num, val1, val2, val3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.spinner);
        imgBtn1 = findViewById(R.id.imgBtn1);
        imgBtn2 = findViewById(R.id.imgBtn2);
        imgBtn3 = findViewById(R.id.imgBtn3);
        text1 = findViewById(R.id.text1);
        text2 = findViewById(R.id.Text2);
        text3 = findViewById(R.id.text3);
        editText = findViewById(R.id.editText);


        imgBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (spinner.getSelectedItem().toString().equals("meter") )
                {
                    num = Float.parseFloat(editText.getText().toString());
                    val1 = 100* num;
                    val2 = (float) ((3.28084)* num);
                    val3 = (float) ((39.3701)* num);

                    text1.setText( (String.format("%.2f", val1))+ " cm");
                    text2.setText( (String.format("%.2f", val2))+ " ft");
                    text3.setText( (String.format("%.2f", val3))+ " in");
                }

                else
                {
                    text1.setText("");
                    text2.setText("");
                    text3.setText("");

                    Toast.makeText( MainActivity.this ,  "Kindly select correct conversion icon",Toast.LENGTH_LONG).show();

                }

            }
        });

        imgBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (spinner.getSelectedItem().toString().equals("celsius"))
                {
                    num = Float.parseFloat(editText.getText().toString());
                    val1 = (float)(9* num)/5 +32;
                    val2 = (float)(num + 273.151);

                    text1.setText( (String.format("%.2f", val1))+ " fahrenheit");
                    text2.setText( (String.format("%.2f", val2)) + " kelvin");
                    text3.setText("");
                }

                else
                {
                    text1.setText("");
                    text2.setText("");
                    text3.setText("");

                    Toast.makeText( MainActivity.this ,  "Kindly select correct conversion icon",Toast.LENGTH_LONG).show();

                }

            }
        });

        imgBtn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (spinner.getSelectedItem().toString().equals("kilogram"))
                {
                    num = Float.parseFloat(editText.getText().toString());
                    val1 = 1000* num;
                    val2 = (float) ((35.274)* num);
                    val3 = (float) ((2.205)* num);

                    text1.setText( (String.format("%.2f", val1)) + " grams");
                    text2.setText( (String.format("%.2f", val2)) + " ounces");
                    text3.setText( (String.format("%.2f", val3)) + " pound");
                }

                else
                {
                    text1.setText("");
                    text2.setText("");
                    text3.setText("");

                    Toast.makeText( MainActivity.this ,  "Kindly select correct conversion icon",Toast.LENGTH_LONG).show();

                }

            }
        });


    }
}